"""Databricks ML Bundle CLI - Generate ML platform project structures."""

__version__ = "0.1.0"
